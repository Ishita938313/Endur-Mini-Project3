package com.cyan.hotel;

import com.cyan.hotel.controller.HomeController;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelApplicationTests {
    HomeController homeController;

    @Test
    void contextLoads() {

    }

}
